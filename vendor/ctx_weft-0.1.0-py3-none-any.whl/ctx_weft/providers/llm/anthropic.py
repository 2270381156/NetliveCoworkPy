"""Async Anthropic LLM adapter.

Implements LLMClient protocol using httpx for async HTTP.
Supports streaming via Anthropic SSE protocol.
"""

from __future__ import annotations

import asyncio
import json
import logging
from collections.abc import AsyncIterator
from typing import Any

import httpx

from ctx_weft.protocols import (
    LLMCallError, LLMChunk, LLMClient, LLMMessage, LLMRequest, LLMTool, LLMUsage, ToolCall,
)
from ctx_weft.providers.llm._finalize import build_finalize_chunks, parse_tool_arguments
from ctx_weft.providers.llm._schema import sanitize_boolean_schemas
from ctx_weft.providers.llm.text_calls import (
    ContentGate, merge_content as _merge_content, unwrap_raw_arguments,
)
from ctx_weft.providers.llm.tokenizer import HeuristicTokenizer

logger = logging.getLogger(__name__)

_ANTHROPIC_API_URL = "https://api.anthropic.com"
_ANTHROPIC_VERSION = "2023-06-01"

_NON_RETRIABLE_CODES = frozenset({400, 401, 403, 404})
_RETRIABLE_CODES     = frozenset({429, 500, 502, 503, 504})


class AnthropicAdapter(LLMClient):
    """Async Anthropic Messages API adapter."""

    def __init__(
        self,
        api_key: str,
        model: str = "claude-sonnet-4-6",
        base_url: str = _ANTHROPIC_API_URL,
        context_limit: int = 200_000,
        output_reserve: int = 8192,
        timeout_sec: int = 120,
        max_http_retries: int = 3,
    ) -> None:
        self._api_key = api_key
        self._model = model
        self._base_url = base_url.rstrip("/")
        self._context_limit = context_limit
        self._output_reserve = output_reserve
        self._timeout = timeout_sec
        self._max_http_retries = max_http_retries
        self._client = self._make_client()
        self._tokenizers: dict[str, HeuristicTokenizer] = {}

    def tokenizer_for(self, model: str) -> HeuristicTokenizer:
        """按 model 惰性分桶的校准 tokenizer（_FixedModelClient 经此取绑定模型那只）。"""
        if model not in self._tokenizers:
            self._tokenizers[model] = HeuristicTokenizer()
        return self._tokenizers[model]

    @property
    def tokenizer(self) -> HeuristicTokenizer:
        return self.tokenizer_for(self._model)

    def _make_client(self) -> httpx.AsyncClient:
        """Build the httpx client. Overridable to inject SSL verification."""
        return httpx.AsyncClient(timeout=self._timeout)

    @property
    def model(self) -> str:
        """构造时配置的模型名（duck-typed，非协议必需）：host 裸 adapter 直传时，
        runtime 执行前经 getattr 读取回填 session.llm_model——实际调用一直用它替换
        "mock"（见 _build_payload），事件账面须与之同源。"""
        return self._model

    @property
    def context_limit(self) -> int:
        return self._context_limit

    @property
    def output_reserve(self) -> int:
        return self._output_reserve

    @property
    def supports_tool_calling(self) -> bool:
        return True

    def complete(self, request: LLMRequest, stream: bool = True) -> AsyncIterator[LLMChunk]:
        return self._stream(request)

    async def _stream(self, request: LLMRequest) -> AsyncIterator[LLMChunk]:
        payload = self._build_payload(request)
        headers = self._headers()
        url = f"{self._base_url}/v1/messages"

        produced = False  # 是否已向消费者吐过 chunk（流已开始）
        for attempt in range(self._max_http_retries):
            tool_blocks: dict[int, dict[str, Any]] = {}
            thinking_blocks: dict[int, str] = {}
            input_tokens: int | None = None
            cache_read = 0
            cache_write = 0
            content_text = ""
            finish_reason: str | None = None
            usage: LLMUsage | None = None
            gate = ContentGate()  # 增量剥离 <think>/<tool_call> 标签

            try:
                # 流式 read 超时 = 闲置(自上一字节起)超时,而非整段时长上限:正常流(token/思考/
                # 工具参数分片,以及 Anthropic 周期性 ping)持续来字节会不断重置计时器,故长工具调用/
                # 长思考不会误触发。仅当连接静默(中途断网/死 socket,无字节无 RST)超过 timeout 才触发
                # ReadTimeout(TransportError)→ produced=True 时抛 outage → INTERRUPTED;否则会永久挂起。
                async with self._client.stream(
                    "POST", url, headers=headers, json=payload,
                    timeout=httpx.Timeout(self._timeout, read=self._timeout),
                ) as resp:
                    if resp.status_code != 200:
                        body = await resp.aread()
                        err_body = body.decode()

                        if resp.status_code in _NON_RETRIABLE_CODES:
                            raise LLMCallError(
                                f"Anthropic API error {resp.status_code}: {err_body}",
                                status_code=resp.status_code,
                                retriable=False,
                            )

                        if resp.status_code in _RETRIABLE_CODES and attempt < self._max_http_retries - 1:
                            try:
                                delay = float(resp.headers.get("retry-after", 2 ** attempt))
                            except (ValueError, TypeError):
                                delay = float(2 ** attempt)
                            delay = min(delay, 60.0)
                            logger.warning(
                                "Anthropic API %d (attempt %d/%d), retrying in %.1fs: %.200s",
                                resp.status_code, attempt + 1, self._max_http_retries, delay, err_body,
                            )
                            await asyncio.sleep(delay)
                            continue

                        retry_after_hdr = resp.headers.get("retry-after")
                        try:
                            retry_after_val = float(retry_after_hdr) if retry_after_hdr else None
                        except (ValueError, TypeError):
                            retry_after_val = None
                        is_retriable = resp.status_code in _RETRIABLE_CODES
                        raise LLMCallError(
                            f"Anthropic API error {resp.status_code}: {err_body}",
                            status_code=resp.status_code,
                            retriable=is_retriable,
                            outage=is_retriable,
                            retry_after_sec=retry_after_val,
                        )

                    async for line in resp.aiter_lines():
                        if not line.startswith("data: "):
                            continue
                        data = line[6:]
                        if data == "[DONE]":
                            break
                        try:
                            event = json.loads(data)
                        except json.JSONDecodeError:
                            continue

                        event_type = event.get("type", "")

                        if event_type == "message_start":
                            usage_data = (event.get("message") or {}).get("usage") or {}
                            input_tokens = usage_data.get("input_tokens")
                            cache_read = usage_data.get("cache_read_input_tokens") or 0
                            cache_write = usage_data.get("cache_creation_input_tokens") or 0

                        elif event_type == "content_block_start":
                            block = event.get("content_block") or {}
                            idx = event.get("index", 0)
                            block_type = block.get("type", "")
                            if block_type == "tool_use":
                                tool_blocks[idx] = {
                                    "id": block.get("id", ""),
                                    "name": block.get("name", ""),
                                    "arguments": "",
                                }
                            elif block_type == "thinking":
                                thinking_blocks[idx] = ""

                        elif event_type == "content_block_delta":
                            delta = event.get("delta") or {}
                            delta_type = delta.get("type", "")
                            idx = event.get("index", 0)

                            if delta_type == "text_delta":
                                text = delta.get("text") or ""
                                if text:
                                    content_text = _merge_content(content_text, text)
                                    tok = gate.feed(content_text)
                                    if tok:
                                        produced = True
                                        yield LLMChunk(kind="token", text=tok)

                            elif delta_type == "thinking_delta":
                                thinking = delta.get("thinking") or ""
                                if thinking:
                                    thinking_blocks[idx] = thinking_blocks.get(idx, "") + thinking
                                    produced = True
                                    yield LLMChunk(kind="reasoning", text=thinking)

                            elif delta_type == "input_json_delta":
                                partial = delta.get("partial_json") or ""
                                if idx in tool_blocks:
                                    # merge_content：兼容增量与「字符级前缀重发」两种流式语义，
                                    # 避免重发被盲拼成畸形（同 content 的 N5 防御）。
                                    tool_blocks[idx]["arguments"] = _merge_content(
                                        tool_blocks[idx]["arguments"], partial)
                                    # 见 openai.py：工具调用参数流式期间发无负载心跳，让 act 流式
                                    # 循环顶部的暂停/取消检查点有机会运行；并标记 produced 使断流走
                                    # retriable（任务层干净整跑），而非静默 inline 重发整个长工具调用。
                                    produced = True
                                    yield LLMChunk(kind="tool_call_partial")

                        elif event_type == "message_delta":
                            stop_reason = event.get("delta", {}).get("stop_reason")
                            usage_data = event.get("usage") or {}
                            output_tokens = usage_data.get("output_tokens", 0)
                            # 部分代理在尾包重发输入侧字段——带了就覆盖（以尾包为准）
                            if usage_data.get("input_tokens") is not None:
                                input_tokens = usage_data.get("input_tokens")
                            if usage_data.get("cache_read_input_tokens") is not None:
                                cache_read = usage_data.get("cache_read_input_tokens") or 0
                            if usage_data.get("cache_creation_input_tokens") is not None:
                                cache_write = usage_data.get("cache_creation_input_tokens") or 0
                            # Anthropic 的 input_tokens 不含缓存部分 → 归一为「全部输入」口径，
                            # 保证 core 的 context 阈值/预算拿到真实上下文规模（开缓存后不失真）
                            uncached = input_tokens or 0
                            prompt_total = uncached + cache_read + cache_write
                            usage = LLMUsage(
                                prompt_tokens=prompt_total,
                                completion_tokens=output_tokens,
                                total_tokens=prompt_total + output_tokens,
                                cache_read_tokens=cache_read,
                                cache_write_tokens=cache_write,
                                input_tokens=uncached,
                                # reasoning_tokens 恒 0：thinking 计入 output_tokens 无单列，
                                # 不用流式 thinking 文本估算——估算值混进计费口径就是错账
                            )
                            finish_reason = stop_reason or "stop"
                            break  # 终止事件 → 跳出循环做统一收尾

                    # 流以任何方式结束（message_delta / 自然结束）→ 统一收尾：
                    # 截断判定、native 规整、文本/思考还原、usage、done（见 _finalize）。
                    for ch in build_finalize_chunks(
                        content_text=content_text,
                        native_tool_calls=_parse_tool_blocks(tool_blocks),
                        had_native_buffer=bool(tool_blocks),
                        saw_terminal=finish_reason is not None,
                        usage=usage,
                        finish_reason=finish_reason,
                        emitted_visible_len=gate.emitted_len,
                    ):
                        yield ch
                    return

            except httpx.TransportError as exc:
                # 已吐过 chunk（流中断）→ 不在 adapter 内重试（会重复 token），
                # 抛 retriable 让 TaskManager 整任务干净重跑。
                if produced:
                    logger.warning(
                        "Anthropic stream interrupted mid-flight (tool_call_in_progress=%s): %s",
                        bool(tool_blocks), exc,
                    )
                    raise LLMCallError(
                        f"LLM stream interrupted mid-flight: {exc}", retriable=True, outage=True,
                    ) from exc
                if attempt < self._max_http_retries - 1:
                    delay = float(2 ** attempt)
                    logger.warning(
                        "Anthropic transport error (attempt %d/%d), retrying in %.1fs: %s",
                        attempt + 1, self._max_http_retries, delay, exc,
                    )
                    await asyncio.sleep(delay)
                    continue
                raise LLMCallError(str(exc), retriable=False) from exc

    async def list_models(self) -> list[str]:
        """List available model ids via GET {base}/v1/models. Raises on HTTP error."""
        resp = await self._client.get(f"{self._base_url}/v1/models", headers=self._headers())
        resp.raise_for_status()
        data = resp.json().get("data", [])
        return [m["id"] for m in data if isinstance(m, dict) and "id" in m]

    def _headers(self) -> dict[str, str]:
        return {
            "x-api-key": self._api_key,
            "anthropic-version": _ANTHROPIC_VERSION,
            "Content-Type": "application/json",
        }

    def _build_payload(self, request: LLMRequest) -> dict[str, Any]:
        model = request.model if request.model and request.model != "mock" else self._model
        messages = _serialize_messages(request.messages)
        payload: dict[str, Any] = {
            "model": model,
            "messages": messages,
            "stream": True,
            # 必填字段：网关一般已算好 request.max_tokens；缺时兜底用 output_reserve（预期输出量）。
            "max_tokens": request.max_tokens or self._output_reserve,
        }
        if request.system:
            payload["system"] = request.system
        if request.temperature != 1.0:
            payload["temperature"] = request.temperature
        if request.tools:
            payload["tools"] = _map_tools(request.tools)
        return payload


def _parse_tool_blocks(blocks: dict[int, dict[str, Any]]) -> list[ToolCall]:
    """把累积的 tool_use 块解析成规整 ToolCall：丢弃 id/name 为空者；
    arguments 解析失败先试畸形救援，仍不行才保留 ``{"_raw": ...}`` 交 gateway 报错（不静默丢）。"""
    calls: list[ToolCall] = []
    for tb in blocks.values():
        if not tb["id"] or not tb["name"]:
            continue
        args = parse_tool_arguments(tb["arguments"])
        calls.append(ToolCall(id=tb["id"], name=tb["name"], arguments=args))
    return calls


def _serialize_messages(messages: list[LLMMessage]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    i = 0
    while i < len(messages):
        m = messages[i]
        if m.role == "system":
            i += 1
            continue
        if m.role == "assistant":
            content_blocks: list[dict] = []
            text = m.content if isinstance(m.content, str) else _parts_to_text(m.content)
            if text:
                content_blocks.append({"type": "text", "text": text})
            for tc in (m.tool_calls or []):
                content_blocks.append({
                    "type": "tool_use",
                    "id": tc.get("id", ""),
                    "name": tc.get("name", ""),
                    # 兜底 {"_raw": ...} 解包回真实参数（Anthropic 的 input 必须是对象，无法像
                    # OpenAI 那样回吐原始文本）；真畸形无法解包时保持原样，交 gateway 报错。
                    "input": unwrap_raw_arguments(tc.get("input", tc.get("arguments", {}))),
                })
            result.append({"role": "assistant", "content": content_blocks or text})
            i += 1
        elif m.role == "tool":
            tool_results: list[dict] = []
            while i < len(messages) and messages[i].role == "tool":
                tm = messages[i]
                content = tm.content if isinstance(tm.content, str) else _parts_to_text(tm.content)
                if tm.tool_call_id:
                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": tm.tool_call_id,
                        "content": content,
                    })
                else:
                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": "unknown",
                        "content": content,
                    })
                i += 1
            result.append({"role": "user", "content": tool_results})
        else:
            content = m.content if isinstance(m.content, str) else _parts_to_text(m.content)
            result.append({"role": m.role, "content": content})
            i += 1
    return result


def _parts_to_text(parts: Any) -> str:
    if isinstance(parts, str):
        return parts
    if isinstance(parts, list):
        return " ".join(
            p.get("text", "") if isinstance(p, dict) else str(p) for p in parts
        )
    return str(parts)


def _map_tools(tools: list[LLMTool]) -> list[dict[str, Any]]:
    return [
        {
            "name": t.name,
            "description": t.description,
            "input_schema": sanitize_boolean_schemas(
                t.input_schema or {"type": "object", "properties": {}}
            ),
        }
        for t in tools
    ]
