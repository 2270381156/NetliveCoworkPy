"""Control plane types.

Phase 6 §6.7.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from ctx_weft.core.state.models import HitlRequest


@dataclass
class SessionView:
    """Session 的轻量投影，从事件流 reduce 而来。"""

    id: str
    user_prompt: str = ""
    template_id: str = ""
    status: str = "RUNNING"
    goal: str = ""
    root_agent_id: str = ""
    llm_model: str = ""
    llm_account: str = ""
    tenant_id: str = "default"
    token_budget: int = 200_000
    context_limit: int = 180_000
    reserved_output_tokens: int = 8192
    failure_counter: int = 0
    created_at: datetime | None = None


@dataclass
class TaskView:
    """Task 的轻量投影，从事件流 reduce 而来。"""

    id: str
    session_id: str
    status: str = "PENDING"
    title: str = ""
    description: str = ""
    assigned_agent_id: str = ""
    creator_agent_id: str = ""
    parent_task_id: str = ""
    user_prompt: str = ""
    original_user_prompt: str = ""  # reopen 重写前的原始 prompt 快照（防多轮累加，跨重启保留）
    interaction_mode: str = "auto"  # interactive=纯文本暂停等用户 / auto=自治（跨重启保留，否则 resume 后丢失暂停语义）
    # 派发来源（跨重启保留）：子任务是被父的哪一次 delegate 调用派出来的。丢了则 finalize
    # 认不出自己的派发框，子任务 close 时既不闭合父的 ack、也不合成 finish 对（胶囊丢失）。
    # memory 侧另有 child_task_id 做一等事实，本字段是 in-run 快捷路径 + 存量数据回退。
    origin_tool_call_id: str = ""
    origin_tool_name: str = ""
    settings_raw: dict[str, Any] = field(default_factory=dict)
    dag_deps: list[str] = field(default_factory=list)
    priority: int = 5
    max_retries: int = 3
    timeout_ms: int = 60_000
    tenant_id: str = "default"
    outputs: Any = None
    error: str | None = None
    created_at: datetime | None = None
    finished_at: datetime | None = None


@dataclass
class AgentView:
    """Agent 的轻量投影，从 task 层级推算而来。"""

    id: str
    spawn_depth: int = 0
    parent_agent_id: str | None = None


@dataclass
class RunStateView:
    """Point-in-time view of a run's state for inspect/replay."""

    run_id: str
    session_id: str
    task_id: str
    agent_id: str

    current_step: str | None = None
    task_status: str = "UNKNOWN"
    session_status: str = "UNKNOWN"

    assembled_prompt_tokens: int = 0
    transcript_turns: int = 0
    events_total: int = 0

    target_event_id: str | None = None
    events_replayed: int = 0

    extra: dict[str, Any] = field(default_factory=dict)

    snapshot_at: datetime | None = None

    # Full projections rebuilt from events
    sessions: dict[str, SessionView] = field(default_factory=dict)
    tasks: dict[str, TaskView] = field(default_factory=dict)
    agents: dict[str, AgentView] = field(default_factory=dict)

    # Pending HITL requests folded from events (only unresolved; spec/07 §9)
    pending_hitl: dict[str, "HitlRequest"] = field(default_factory=dict)
